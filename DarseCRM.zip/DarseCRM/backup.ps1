
$ErrorActionPreference = "Stop"

$backupFolder = "C:\DarseCRM\backups"
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"

New-Item -ItemType Directory -Force -Path $backupFolder | Out-Null

$containers = @("espocrm-db", "espocrm", "espocrm-daemon")

try {
    # Check Docker is available
    docker info | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Docker is not running."
    }

    # Stop CRM for a consistent backup
    docker stop espocrm-daemon espocrm espocrm-db

    if ($LASTEXITCODE -ne 0) {
        throw "Could not stop CRM containers."
    }

    # Back up all four volumes
    docker run --rm `
      -v espocrm-db:/db:ro `
      -v espocrm-data:/data:ro `
      -v espocrm-custom:/custom:ro `
      -v espocrm-custom-client:/custom-client:ro `
      -v "C:\DarseCRM\backups:/backup" `
      alpine sh -c "tar -czf /backup/database-$stamp.tar.gz -C /db . && tar -czf /backup/data-$stamp.tar.gz -C /data . && tar -czf /backup/custom-$stamp.tar.gz -C /custom . && tar -czf /backup/custom-client-$stamp.tar.gz -C /custom-client ."

    if ($LASTEXITCODE -ne 0) {
        throw "Backup failed."
    }

    # Remove backups older than 28 days
    Get-ChildItem $backupFolder -Filter "*.tar.gz" |
        Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-28) } |
        Remove-Item -Force
}
finally {
    # Always restart CRM containers
    docker start espocrm-db
    docker start espocrm
    docker start espocrm-daemon
}
